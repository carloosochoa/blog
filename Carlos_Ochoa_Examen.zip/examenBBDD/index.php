<?php
header("Location: ../examenBBDD/usuario/visualizar_usuario.php");
?>